# Instrucciones para una IA que retome este proyecto

Lee este archivo completo antes de hacer cualquier cambio. Resume el contexto, las decisiones ya tomadas y lo que falta.

## Contexto

- **Qué es:** una exposición universitaria para la materia **Computación en la Nube**. Tema: **Ficha 4, "Shadow AI y ataques a la IA"**, de la guía `7 Temas de Exposición_ Cloud + IA.docx` (en la raíz del repo; incluye la estructura obligatoria y la rúbrica).
- **Idioma:** todo en **español** (Colombia). Responde al usuario en español.
- **Expositor único:** el usuario presenta **solo**, sin grupo. El guion y la guía están escritos en primera persona para una sola persona que habla y maneja la demo a la vez. No reintroduzcas repartos por integrante.
- **Formato exigido:** 15 a 20 minutos de exposición, 5 de demo, 5 a 10 de preguntas. Estructura: problema → cómo funciona → caso real → riesgos y dilemas → postura (la del expositor).
- **Repo:** https://github.com/brandongarces82221-debug/Exposition-shadow-ia (rama `main`).

## Restricciones del usuario (respetarlas)

1. **Cuenta de AWS con pocos créditos:** todo debe ser barato y liviano.
2. **Simple:** usar la **VPC por defecto**; no crear VPC, subredes, NAT ni balanceadores. "Solo es una demo."
3. **"Que solo sea levantarlo y que funcione":** un `terraform apply` debe dejar todo funcionando sin pasos manuales (salvo habilitar el modelo en Bedrock).
4. Infraestructura con **Terraform** (cuando el usuario dijo "tesseract" se refería a Terraform).

## Estructura del repo

```
README.md                         Portada del repo
.gitignore                        Excluye *.tfstate, .terraform/, *.tfvars
7 Temas de Exposición_ ... .docx  Guía del profesor (fuente de los requisitos)
demo-aws/
  README.md                       Cómo levantar, costos, guion de la demo, fallas comunes
  app/app.py                      Servidor HTTP (stdlib) + anthropic + boto3
  app/index.html                  Interfaz: chat, inyección indirecta, contadores, QR
  terraform/main.tf               EC2, SG, IAM, Bedrock Guardrail
  terraform/variables.tf          region, instance_type, model_id, secret_code, allowed_cidr
  terraform/outputs.tf            url, guardrail_id, instance_id
  terraform/cloud-init.yaml.tftpl Instala Python 3.11, la app y el servicio systemd
material-estudio.zip              Guion, guía de estudio y este archivo
```

## Cómo funciona la demo "Hackea a Uni"

- El curso intenta que "Uni", el asistente de la Facultad, revele el código `DRAGON-7731` (ficticio, guardado a propósito en el prompt del sistema).
- **Modo "sin"**: el mensaje va directo al modelo. **Modo "con"**: `ApplyGuardrail` revisa la entrada (`source=INPUT`) y la salida (`source=OUTPUT`). Mismo prompt y mismo modelo en ambos modos: la única variable es el guardrail.
- Endpoints de `app.py`: `GET /`, `GET /health`, `GET /api/stats`, `GET /qr.svg` (QR con `http://<Host>`), `POST /api/chat`, `POST /api/resumir`, `POST /api/reset`.
- `MOCK=1` simula las respuestas sin AWS (para ensayar y para probar cambios localmente).
- El código se detecta en la salida normalizando a alfanumérico (`filtro_secreto`), y así se cuentan las "filtraciones".

## Decisiones técnicas ya tomadas (no cambiarlas sin preguntar)

| Decisión | Motivo |
|---|---|
| Modelo **Claude Haiku 4.5** con el perfil de inferencia `global.anthropic.claude-haiku-4-5-20251001-v1:0`, vía `AnthropicBedrock` (endpoint `bedrock-runtime`, InvokeModel) | Es el único modelo con el acuerdo `AVAILABLE` en la cuenta del usuario (Haiku 5.5, Sonnet 5 y otros dan `NOT_AVAILABLE`). El ID sin prefijo `global.`/`us.` falla (no admite throughput on-demand). Por `bedrock-mantle` da 403. |
| SDK fijado en `anthropic[bedrock]>=1.17,<2` (cloud-init) | La 2.x envía la versión de API `2026-10-21`, que Bedrock solo acepta para modelos 4.7+. Sin `effort` ni `thinking` (Haiku 4.5 no usa `effort`). Si algún día se cambia a un modelo 4.7+, se puede subir a la 2.x. |
| Guardrails con `ApplyGuardrail` en `bedrock-runtime` (boto3), separado de la llamada al modelo | Funciona independiente del endpoint del modelo y permite mostrar qué capa bloqueó. |
| Permisos de IAM: `bedrock:InvokeModel` (sobre `*`, porque el perfil global enruta a cualquier región) y `bedrock:ApplyGuardrail` (solo sobre el ARN del guardrail), más `AmazonSSMManagedInstanceCore` | Mínimo privilegio; SSM permite entrar sin abrir SSH. |
| EC2 `t3.micro`, Amazon Linux 2023, IMDSv2 obligatorio, servicio systemd con `DynamicUser` y `CAP_NET_BIND_SERVICE` en el puerto 80 | Simple y barato. |
| Archivos de la app como **texto plano** en `write_files` de cloud-init y user_data con `base64gzip` | El límite de user_data es 16 KB; ahora ocupa unos 8 KB. Si crecen mucho los archivos, revisar el tamaño. |
| Guardrail en versión `DRAFT` | Suficiente para la demo. |
| Políticas del guardrail: PROMPT_ATTACK (HIGH en entrada), tema prohibido "Credenciales internas" y regex generada desde `var.secret_code` que tolera separadores | Muestra tres capas distintas. |

## Diapositivas

- 15 diapositivas en un artefacto de Claude (privado): https://claude.ai/artifact/28BiHkCTfJozDXuNq4vouv
- Solo puede verlo o editarlo la cuenta del dueño, salvo que lo comparta desde **Share**. Si no tienes acceso, pide al usuario una exportación a PDF o PowerPoint.
- El guion (`01-guion-exposicion.md`) sigue el orden y el contenido de esas diapositivas.

## Estado y pendientes

**Verificado:**
- `terraform validate` y `terraform fmt` pasan con Terraform 1.17 y el proveedor AWS `~> 6.0`.
- La app funciona en modo `MOCK` (todos los endpoints).
- El QR se genera bien.
- El cloud-init renderizado reproduce `app.py` e `index.html` byte por byte.

**NO verificado:**
- **Nunca se ha hecho un `terraform apply` real.** El primer despliegue puede revelar errores: acceso al modelo, nombres de acciones de IAM o idioma del guardrail.
- No se ha escaneado el QR con un celular.

**Pendiente del usuario:**
1. ~~Habilitar el modelo~~: Claude Haiku 4.5 ya está habilitado y probado en la cuenta (responde por `bedrock-runtime`).
2. Ensayo real en AWS (ver los riesgos abajo).
3. Caso de América Latina para la diapositiva 11 (verificado; no inventarlo).
4. Dos fuentes adicionales para la diapositiva 15.
5. Verificar el caso Samsung 2023 en la fuente original.
6. Su nombre y la fecha en la portada.

## Riesgos conocidos y cómo depurar

- **Haiku 4.5 puede resistir los ataques aun sin guardrails.** Si en el ensayo nadie logra sacar el código, se puede debilitar el prompt de `SYSTEM_CHAT` en `app.py` (por ejemplo, decir que el código se puede compartir con quien demuestre ser profesor). Preguntar antes al usuario.
- **El tema prohibido o el filtro de ataques podrían funcionar peor en español.** Probarlo en el ensayo.
- Si la página no carga: Session Manager → `sudo journalctl -u demo -n 50` y `sudo cat /var/log/cloud-init-output.log`.
- Si aparece `AccessDenied` al llamar al modelo: revisar el acceso al modelo en Bedrock y la acción de IAM `bedrock:InvokeModel`.
- Un cambio en `app.py` o `index.html` reemplaza la instancia en el siguiente `apply` (`user_data_replace_on_change = true`), y la IP pública cambia. El QR se ajusta solo.

## Reglas para quien retome

- No subas `*.tfstate` ni credenciales. El `.gitignore` ya los excluye.
- No inventes estadísticas, casos ni citas. Usa placeholders entre corchetes y avisa.
- Prueba los cambios a la app con `MOCK=1 PORT=8000 python3 app/app.py` antes de hacer commit.
- Después de cambiar Terraform: `terraform fmt` y `terraform validate`.
- Mantén todo simple y barato. Si una mejora agrega costo o complejidad, pregunta antes.
- Cada commit lleva un mensaje claro en español.
